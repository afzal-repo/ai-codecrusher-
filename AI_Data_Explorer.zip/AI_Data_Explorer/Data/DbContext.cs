﻿using Azure;
using Azure.AI.OpenAI;
using AI_Data_Explorer.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Text.Json;

namespace AI_Data_Explorer.Data
{
    public static class DbContext
    {
        public static IndexModel RunQuery(string userPrompt)
        {
            var indexModel = new IndexModel();
            // Configure OpenAI client
            //string openAIEndpoint = "https://apazureopenai.openai.azure.com/";
            //string openAIKey = "ba9fdb734ba84ac1bc28c3ad09e6e037";
            //string openAIDeploymentName = "gpt-4";

            string openAIEndpoint = "https://azureopenaidataexplorer.openai.azure.com/";
            string openAIKey = "2bcECO2JXLwUWvR67rXbdL5fDSYBpuqPGzMNa3fE47sd8qESgdMHJQQJ99AKACHrzpqXJ3w3AAABACOGy4QW";
            string openAIDeploymentName = "gpt-4";

            OpenAIClient client = new(new Uri(openAIEndpoint), new AzureKeyCredential(openAIKey));

            var systemMessage = @"Your are a helpful, cheerful database assistant. 
            Use the following database schema when creating your answers:

            {
              ""schema"": {
                ""Products"": {
                  ""columns"": {
                    ""ProductID"": ""INT PRIMARY KEY IDENTITY(1,1)"",
                    ""Name"": ""NVARCHAR(MAX) NOT NULL"",
                    ""Description"": ""NVARCHAR(MAX)"",
                    ""Price"": ""DECIMAL(10, 2) NOT NULL"",
                    ""Available"": ""INT NOT NULL""
                  }
                },
                ""Customers"": {
                  ""columns"": {
                    ""CustomerID"": ""INT PRIMARY KEY IDENTITY(1,1)"",
                    ""FirstName"": ""NVARCHAR(MAX) NOT NULL"",
                    ""LastName"": ""NVARCHAR(MAX) NOT NULL"",
                    ""Email"": ""NVARCHAR(200) NOT NULL UNIQUE"",
                    ""Phone"": ""NVARCHAR(MAX)"",
                    ""Address"": ""NVARCHAR(MAX)"",
                    ""City"": ""NVARCHAR(MAX)"",
                    ""State"": ""NVARCHAR(MAX)"",
                    ""ZipCode"": ""NVARCHAR(MAX)"",
                    ""Country"": ""NVARCHAR(MAX)"",
                    ""CreatedAt"": ""DATETIME DEFAULT GETDATE()""
                  }
                },
                ""Orders"": {
                  ""columns"": {
                    ""OrderID"": ""INT PRIMARY KEY IDENTITY(1,1)"",
                    ""CustomerID"": ""INT NOT NULL"",
                    ""ProductID"": ""INT NOT NULL"",
                    ""OrderDate"": ""DATETIME DEFAULT GETDATE()"",
                    ""Quantity"": ""INT NOT NULL"",
                    ""TotalAmount"": ""DECIMAL(10, 2) NOT NULL""
                  },
                  ""foreignKeys"": {
                    ""CustomerID"": ""REFERENCES Customers(CustomerID)"",
                    ""ProductID"": ""REFERENCES Products(ProductID)""
                  }
                },
                ""Sales"": {
                  ""columns"": {
                    ""SaleID"": ""INT PRIMARY KEY IDENTITY(1,1)"",
                    ""OrderID"": ""INT NOT NULL"",
                    ""ProductID"": ""INT NOT NULL"",
                    ""SaleDate"": ""DATETIME DEFAULT GETDATE()"",
                    ""TotalSaleAmount"": ""DECIMAL(10, 2) NOT NULL""
                  },
                  ""foreignKeys"": {
                    ""OrderID"": ""REFERENCES Orders(OrderID)"",
                    ""ProductID"": ""REFERENCES Products(ProductID)""
                  }
                },
                ""OrderDetails"": {
                  ""columns"": {
                    ""OrderDetailID"": ""INT PRIMARY KEY IDENTITY(1,1)"",
                    ""OrderID"": ""INT NOT NULL"",
                    ""ProductID"": ""INT NOT NULL"",
                    ""Quantity"": ""INT NOT NULL"",
                    ""UnitPrice"": ""DECIMAL(10, 2) NOT NULL"",
                    ""TotalAmount"": ""DECIMAL(10, 2) NOT NULL""
                  },
                  ""foreignKeys"": {
                    ""OrderID"": ""REFERENCES Orders(OrderID)"",
                    ""ProductID"": ""REFERENCES Products(ProductID)""
                  }
                }
              }
            }



            Include column name headers in the query results.

            Always provide your answer in the JSON format below:
            
            { ""summary"": ""your-summary"", ""query"":  ""your-query"" }
            
            Output ONLY JSON.
            In the preceding JSON response, substitute ""your-query"" with Microsoft SQL Server Query to retrieve the requested data.
            In the preceding JSON response, substitute ""your-summary"" with a summary of the query.
            Always include all columns in the table.
            If the resulting query is non-executable, replace ""your-query"" with NA, but still substitute ""your-query"" with a summary of the query.
            Do not use MySQL syntax.
            Always limit the SQL Query to 100 rows.";

            ChatCompletionsOptions chatCompletionsOptions = new ChatCompletionsOptions()
            {
                Messages = {
                    new ChatRequestSystemMessage(systemMessage),
                    new ChatRequestUserMessage(userPrompt)
                },
                DeploymentName = openAIDeploymentName
            };

            // Send request to Azure OpenAI model
            try
            {
                ChatCompletions chatCompletionsResponse = client.GetChatCompletions(chatCompletionsOptions);

                var response = JsonSerializer
                    .Deserialize<AIQuery>(chatCompletionsResponse.Choices[0].Message.Content
                    .Replace("```json", "").Replace("```", ""));


                indexModel.Summary = response.summary;
                indexModel.Query = response.query;
                indexModel.RowData = DataService.GetDataTable(response.query);
            }
            catch (Exception e)
            {
                indexModel.Error = e.Message;
            }

            return indexModel;
        }
    }
}
