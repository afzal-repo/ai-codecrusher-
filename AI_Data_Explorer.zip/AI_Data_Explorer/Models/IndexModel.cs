﻿using System.ComponentModel.DataAnnotations;

namespace AI_Data_Explorer.Models
{
    public class IndexModel
    {
        [Required(ErrorMessage = "Please enter a prompt.")]
        public string UserPrompt { get; set; }
        public List<List<string>> RowData { get; set; }
        public string Summary { get; set; } = string.Empty;
        public string Query { get; set; } = string.Empty;
        public string Error { get; set; } = string.Empty;
    }
}
