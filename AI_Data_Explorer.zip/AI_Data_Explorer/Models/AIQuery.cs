﻿namespace AI_Data_Explorer.Models
{
    public class AIQuery
    {
        public string summary { get; set; }
        public string query { get; set; }
    }
}
