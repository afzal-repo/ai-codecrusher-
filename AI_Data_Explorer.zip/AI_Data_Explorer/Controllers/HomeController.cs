using AI_Data_Explorer.Data;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using AI_Data_Explorer.Models;

namespace AI_Data_Explorer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var model = new IndexModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(IndexModel inputModel)
        {
            // Process the prompt and set the model properties
            // Populate model.Error, model.Summary, model.Query, and model.RowData as necessary
            var model = DbContext.RunQuery(inputModel.UserPrompt);

            return View(model);

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
